package com.pedro.encoder.input.decoder;

/**
 * Created by pedro on 6/07/17.
 */

public interface AudioDecoderInterface {

  void onAudioDecoderFinished();
}
