package com.pedro.encoder.utils.gl;

/**
 * Created by pedro on 18/11/17.
 */

public enum TranslateTo {

  CENTER, LEFT, RIGHT, TOP, BOTTOM, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT
}
