package com.pedro.rtplibrary.view;

import android.graphics.Bitmap;

/**
 * Created by pedro on 16/07/18.
 */

public interface TakePhotoCallback {

  void onTakePhoto(Bitmap bitmap);
}
