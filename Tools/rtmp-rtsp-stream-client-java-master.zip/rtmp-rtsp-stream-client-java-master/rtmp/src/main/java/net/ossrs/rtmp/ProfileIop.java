package net.ossrs.rtmp;

/**
 * Created by pedro on 18/12/17.
 */

public class ProfileIop {

  public static final byte BASELINE = 0x00;
  public static final byte CONSTRAINED = (byte) 0xC0;
}
