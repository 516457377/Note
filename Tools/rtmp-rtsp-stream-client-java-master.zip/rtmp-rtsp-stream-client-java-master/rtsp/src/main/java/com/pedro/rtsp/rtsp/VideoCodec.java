package com.pedro.rtsp.rtsp;

/**
 * Created by pedro on 28/11/18.
 */

public enum VideoCodec {
  H264, H265
}
