package com.pedro.rtsp.rtsp;

/**
 * Created by pedro on 24/02/17.
 */

public enum Protocol {
  UDP, TCP
}
